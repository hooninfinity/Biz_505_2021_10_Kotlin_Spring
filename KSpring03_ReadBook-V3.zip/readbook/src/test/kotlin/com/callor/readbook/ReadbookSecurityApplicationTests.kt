package com.callor.readbook

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ReadbookSecurityApplicationTests {

	@Test
	fun contextLoads() {
	}

}
